/**
 
*/

/*
   
*/

#include "mcc_generated_files/mcc.h"
#include <xc.h>
#define _XTAL_FREQ 8000000
#define PWM_Frequency 0.5// in kHz (500Hz)

/*
                         Main application
 */
uint8_t data2;
uint8_t data1;
uint8_t ii;
float Value; 
uint16_t dutycycle;
double TempValue; //variable to store value from ADC
int count; //timer variable 
//double Frequency = 50; //calculate Total Time from frequency (in milli sec)) //2msec
double Frequency = (1/PWM_Frequency)/10; //calculate Total Time from frequency (in milli sec)) //2msec
double T_ON = 0; //value of on time of the PWM signal
double T_OFF =0; //value of off time of the PWM signal 
double DutyCycle; //Duty cycle value of the PWM signal
double TempOut; // temperature scaled up value 



void EUSART2_2_ISR()
{
    EUSART2_Receive_ISR();
    
    while(!EUSART2_is_rx_ready());
    data2=EUSART2_Read();
    
    while(!EUSART2_is_tx_ready());
    EUSART1_Write(data2);
    
    while(!EUSART1_is_tx_done());
   
    }

void EUSART1_1_ISR()
{
    EUSART1_Receive_ISR();
    
    while(!EUSART1_is_rx_ready());
    data1=EUSART1_Read();
    
    while(!EUSART2_is_tx_ready());
    EUSART2_Write(data1);
    
    while(!EUSART2_is_tx_done());
   
    }

void Timer_ISR()
{
    if(TMR2IF == 1) // Timer flag has been triggered due to timer overflow -> set to overflow for every 0.1ms
         {
            TMR2 = 248;     //Load the timer Value
            TMR2IF = 0;       // Clear timer interrupt flag
            count++; //Count increments for every 0.1ms -> count/10 will give value of count in ms 
         } 
    
       if (count <= (T_ON) )
        {
            Ser_SetHigh();
        }
       else
        {
            Ser_SetLow();
        }
       
       if (count >= (Frequency*10) )
            count=0;
}

void main(void)
{
   
    SYSTEM_Initialize(); // Initialize the device
    ADC_Initialize();
    PWM5_Initialize();
    
    
    EUSART2_SetRxInterruptHandler(EUSART2_2_ISR);
    EUSART1_SetRxInterruptHandler(EUSART1_1_ISR);
    TMR2_SetInterruptHandler(Timer_ISR);
    
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    TMR2 = 248;     //Load the timer Value
    TMR2IE = 1;     // Enabling TMR2 interrupt.
    
    
    
    
    while(1)
    {
       
        
       TempValue = ADC_GetConversion(TempSensor); //Read the value of TempSensor using ADC
       
       PWM5_LoadDutyValue(dutycycle);
       
       DutyCycle = ((TempValue * 3.33)- 2800) ; //Map 0 to 1024 to 0 to 100
       TempOut = (TempValue * 9.765625); // map 0 to 1024 to 0 to 10000
       T_ON = ((DutyCycle * Frequency)*2 ); //Calculate On Time using formula unit in milli seconds 
       
       
       __delay_ms(100);     
       
       if (TempOut > 8285) //if true turn on LED
       {
           LED_SetHigh();
           
       }
       else // if False turn off LED 
       {
           LED_SetLow();
           //Ser_SetLow();
       }
       
       ii=0;

        __delay_ms(100);  
        
      
    }
   
}

/**
 End of File
*/